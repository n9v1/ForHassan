module.exports = async (client) => {
  console.log(`[API] Logged in as ${client.user.username}`);
  await client.user.setActivity("MusicBot 24/7 - 497g",{ type: 'PLAYING'});
};